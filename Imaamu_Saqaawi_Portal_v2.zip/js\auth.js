/**
 * auth.js
 * Handles authentication logic
 */

const AuthManager = {
    SESSION_KEY: 'isp_session',

    login(usernameOrId, password, role) {
        // Clear previous session
        this.logout();

        if (role === 'admin') {
            const users = DataManager.getUsers();
            const admin = users.find(u => u.username === usernameOrId && u.password === password && u.role === 'admin');
            if (admin) {
                this.setSession(admin);
                return { success: true, user: admin };
            }
        } else if (role === 'student') {
            const students = DataManager.getStudents();
            const student = students.find(s => s.id === usernameOrId && s.password === password);
            if (student) {
                // Attach role for session handling
                const sessionUser = { ...student, role: 'student' };
                this.setSession(sessionUser);
                return { success: true, user: sessionUser };
            }
        }

        return { success: false, message: 'Invalid credentials' };
    },

    logout() {
        localStorage.removeItem(this.SESSION_KEY);
        window.location.reload(); // Simple redirect to login
    },

    setSession(user) {
        localStorage.setItem(this.SESSION_KEY, JSON.stringify(user));
    },

    getCurrentUser() {
        return JSON.parse(localStorage.getItem(this.SESSION_KEY));
    },

    isAuthenticated() {
        return !!this.getCurrentUser();
    }
};
