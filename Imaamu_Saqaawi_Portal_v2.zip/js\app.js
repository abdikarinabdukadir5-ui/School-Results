/**
 * app.js
 * Main application entry point and controller
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initialize Data API
    DataManager.init();

    // Check initial auth state
    const currentUser = AuthManager.getCurrentUser();

    // Simulate loading for smooth feel
    setTimeout(() => {
        const loader = document.querySelector('.loader-container');
        if (loader) loader.classList.add('hidden');

        if (currentUser) {
            UIManager.renderDashboard(currentUser);
        } else {
            UIManager.renderLogin();
        }
    }, 800);
});
