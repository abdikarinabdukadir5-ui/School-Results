/**
 * data.js
 * Handles all data persistence using localStorage
 */

const DataManager = {
    KEYS: {
        USERS: 'isp_users',
        STUDENTS: 'isp_students',
        ADMIN_EXISTS: 'isp_admin_init'
    },

    init() {
        if (!localStorage.getItem(this.KEYS.ADMIN_EXISTS)) {
            this.seedData();
        }
    },

    seedData() {
        // Default Admin
        const admin = {
            id: 'ADMIN01',
            username: 'admin',
            password: 'password123', // In a real app, this should be hashed
            role: 'admin',
            name: 'School Administrator'
        };

        // Dummy Students
        const students = [
            {
                id: 'STU001',
                password: '123',
                fullName: 'Abdi Ali',
                grade: 'Grade 8',
                parentPhone: '252615000000',
                fees: { status: 'Paid', amount: 300, due: 0 },
                subjects: [
                    { name: 'Mathematics', marks: 85, grade: 'A' },
                    { name: 'Science', marks: 78, grade: 'B+' },
                    { name: 'Somali', marks: 92, grade: 'A+' },
                    { name: 'English', marks: 65, grade: 'B' },
                    { name: 'Islamic Studies', marks: 95, grade: 'A+' }
                ]
            },
            {
                id: 'STU002',
                password: '123',
                fullName: 'Fatima Ahmed',
                grade: 'Grade 7',
                parentPhone: '252615000001',
                fees: { status: 'Unpaid', amount: 0, due: 300 },
                subjects: [
                    { name: 'Mathematics', marks: 95, grade: 'A+' },
                    { name: 'Science', marks: 88, grade: 'A' },
                    { name: 'Somali', marks: 89, grade: 'A' },
                    { name: 'English', marks: 90, grade: 'A' },
                    { name: 'Islamic Studies', marks: 98, grade: 'A+' }
                ]
            }
        ];

        localStorage.setItem(this.KEYS.USERS, JSON.stringify([admin]));
        localStorage.setItem(this.KEYS.STUDENTS, JSON.stringify(students));
        localStorage.setItem(this.KEYS.ADMIN_EXISTS, 'true');
        console.log('Database seeded successfully.');
    },

    // --- User (Admin) Methods ---
    getUsers() {
        return JSON.parse(localStorage.getItem(this.KEYS.USERS) || '[]');
    },

    // --- Student Methods ---
    getStudents() {
        return JSON.parse(localStorage.getItem(this.KEYS.STUDENTS) || '[]');
    },

    getStudentById(id) {
        const students = this.getStudents();
        return students.find(s => s.id === id);
    },

    addStudent(studentData) {
        const students = this.getStudents();
        // Check duplicate ID
        if (students.find(s => s.id === studentData.id)) {
            throw new Error('Student ID already exists.');
        }
        students.push(studentData);
        this.saveStudents(students);
        return studentData;
    },

    updateStudent(id, updatedData) {
        let students = this.getStudents();
        const index = students.findIndex(s => s.id === id);
        if (index === -1) throw new Error('Student not found.');

        students[index] = { ...students[index], ...updatedData };
        this.saveStudents(students);
        return students[index];
    },

    deleteStudent(id) {
        let students = this.getStudents();
        const newStudents = students.filter(s => s.id !== id);
        this.saveStudents(newStudents);
    },

    saveStudents(students) {
        localStorage.setItem(this.KEYS.STUDENTS, JSON.stringify(students));
    }
};
