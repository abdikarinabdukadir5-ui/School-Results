/**
 * ui.js
 * Handles DOM manipulation and View Rendering
 */

const UIManager = {
    app: document.getElementById('app'),

    clearApp() {
        this.app.innerHTML = '';
    },

    renderLogin() {
        this.clearApp();
        const loginContainer = document.createElement('div');
        loginContainer.className = 'container flex items-center justify-center p-4';
        loginContainer.style.minHeight = '100vh';

        loginContainer.innerHTML = `
            <div class="card" style="width: 100%; max-width: 450px;">
                <div class="brand-logo">
                    <i class="fas fa-school brand-icon"></i>
                    <div class="brand-text">
                        <h1>Imaamu Saqaawi</h1>
                        <p>Results Portal</p>
                    </div>
                </div>

                <div class="flex justify-center mb-4 gap-4" id="role-toggles">
                    <button class="btn btn-primary w-full" id="btn-role-student">Student</button>
                    <button class="btn btn-outline w-full" id="btn-role-admin">Admin</button>
                </div>

                <form id="login-form">
                    <h2 class="text-center mb-4" id="login-title">Student Login</h2>
                    
                    <div class="form-group">
                        <label class="form-label">ID / Username</label>
                        <input type="text" class="form-input" id="username" placeholder="Enter Student ID" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-input" id="password" placeholder="Enter Password" required>
                    </div>

                    <button type="submit" class="btn btn-primary w-full">Login</button>
                    <p id="error-msg" class="text-center mt-4 hidden" style="color: var(--danger-color)"></p>
                </form>
            </div>
        `;

        this.app.appendChild(loginContainer);

        // Logic for toggles
        const btnStudent = document.getElementById('btn-role-student');
        const btnAdmin = document.getElementById('btn-role-admin');
        const loginTitle = document.getElementById('login-title');
        const usernameInput = document.getElementById('username');
        let currentRole = 'student';

        // Event Listeners for Login
        btnStudent.addEventListener('click', () => {
            currentRole = 'student';
            btnStudent.className = 'btn btn-primary w-full';
            btnAdmin.className = 'btn btn-outline w-full';
            loginTitle.textContent = 'Student Login';
            usernameInput.placeholder = 'Enter Student ID';
        });

        btnAdmin.addEventListener('click', () => {
            currentRole = 'admin';
            btnAdmin.className = 'btn btn-primary w-full';
            btnStudent.className = 'btn btn-outline w-full';
            loginTitle.textContent = 'Admin Login';
            usernameInput.placeholder = 'Enter Admin Username';
        });

        document.getElementById('login-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const username = usernameInput.value.trim();
            const password = document.getElementById('password').value.trim();
            const errorMsg = document.getElementById('error-msg');

            const result = AuthManager.login(username, password, currentRole);

            if (result.success) {
                this.renderDashboard(result.user);
            } else {
                errorMsg.textContent = result.message;
                errorMsg.classList.remove('hidden');
            }
        });
    },

    renderDashboard(user) {
        if (user.role === 'admin') {
            this.renderAdminDashboard(user);
        } else {
            this.renderStudentDashboard(user);
        }
    },

    // --- Admin Dashboard ---
    renderAdminDashboard(user) {
        this.clearApp();
        const dashboard = document.createElement('div');
        dashboard.className = 'dashboard flex flex-col min-h-screen';

        dashboard.innerHTML = `
            <!-- Navbar -->
            <nav class="flex items-center justify-between p-4 bg-white shadow-sm">
                <div class="flex items-center gap-2">
                    <i class="fas fa-school text-2xl text-accent"></i>
                    <div>
                        <h2 class="font-bold text-lg">Admin Portal</h2>
                        <span class="text-sm text-gray-500">Imaamu Saqaawi School</span>
                    </div>
                </div>
                <button id="logout-btn" class="btn btn-outline btn-sm">Logout</button>
            </nav>

            <div class="flex flex-1">
                <!-- Sidebar -->
                <aside class="w-64 bg-slate-800 text-white hidden md:block">
                    <div class="p-6">
                        <ul class="space-y-4">
                            <li><a href="#" class="block p-2 rounded hover:bg-slate-700 font-medium">Students</a></li>
                            <!-- Placeholder for more links -->
                        </ul>
                    </div>
                </aside>

                <!-- Main Content -->
                <main class="flex-1 p-6" id="main-content">
                    <header class="flex justify-between items-center mb-6">
                        <h1 class="text-2xl font-bold">Student Management</h1>
                        <button class="btn btn-primary" id="add-student-btn"><i class="fas fa-plus mr-2"></i> Add Student</button>
                    </header>

                    <!-- User Stats -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                        <div class="card p-4 border-l-4 border-blue-500">
                            <h3 class="text-gray-500 text-sm">Total Students</h3>
                            <p class="text-2xl font-bold" id="total-students-count">0</p>
                        </div>
                    </div>

                    <!-- Filter -->
                    <div class="mb-4">
                        <input type="text" id="search-student" class="form-input" placeholder="Search by Name or ID...">
                    </div>

                    <!-- Table -->
                    <div class="bg-white rounded-lg shadow overflow-hidden">
                        <table class="w-full text-left border-collapse">
                            <thead class="bg-slate-50 text-slate-600 uppercase text-xs">
                                <tr>
                                    <th class="p-4 border-b">ID</th>
                                    <th class="p-4 border-b">Name</th>
                                    <th class="p-4 border-b">Grade</th>
                                    <th class="p-4 border-b">Fees</th>
                                    <th class="p-4 border-b text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="student-table-body" class="text-sm">
                                <!-- Rows generated here -->
                            </tbody>
                        </table>
                    </div>
                </main>
            </div>
            
            <!-- Modal (Hidden by default) -->
            <div id="student-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
                <div class="card w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto">
                    <h2 class="text-xl font-bold mb-4" id="modal-title">Add New Student</h2>
                    <form id="student-form">
                        <input type="hidden" id="edit-mode-id">
                        <div class="grid grid-cols-2 gap-4">
                            <div class="form-group col-span-2">
                                <label class="block text-sm font-medium mb-1">Full Name</label>
                                <input type="text" id="inp-name" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label class="block text-sm font-medium mb-1">Student ID</label>
                                <input type="text" id="inp-id" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label class="block text-sm font-medium mb-1">Password</label>
                                <input type="text" id="inp-password" class="form-input" value="123" required>
                            </div>
                            <div class="form-group">
                                <label class="block text-sm font-medium mb-1">Grade</label>
                                <input type="text" id="inp-grade" class="form-input" required>
                            </div>
                            <div class="form-group">
                                <label class="block text-sm font-medium mb-1">Parent Phone</label>
                                <input type="text" id="inp-phone" class="form-input">
                            </div>
                            
                            <hr class="col-span-2 my-2 border-gray-200">
                            <h4 class="col-span-2 font-bold mb-2 text-sm text-gray-500 uppercase">Fees & Academics</h4>

                            <div class="form-group">
                                <label class="block text-sm font-medium mb-1">Fee Status</label>
                                <select id="inp-fee-status" class="form-input">
                                    <option value="Paid">Paid</option>
                                    <option value="Unpaid">Unpaid</option>
                                </select>
                            </div>
                            
                             <!-- Simplified Subject Entry (Just JSON text area for now or simple fields) -->
                             <!-- To keep it simple but functional, let's auto-generate empty subjects if new, or editable list -->
                             <div class="col-span-2">
                                <label class="block text-sm font-medium mb-1">Marks (JSON Format for now)</label>
                                <textarea id="inp-marks" class="form-input text-xs font-mono h-24" placeholder='[{"name":"Math","marks":80,"grade":"A"}]'></textarea>
                                <p class="text-xs text-gray-400 mt-1">Enter valid JSON for marks.</p>
                             </div>
                        </div>

                        <div class="flex justify-end gap-3 mt-6">
                            <button type="button" class="btn btn-outline" id="close-modal">Cancel</button>
                            <button type="submit" class="btn btn-primary" id="save-student">Save Student</button>
                        </div>
                    </form>
                </div>
            </div>
        `;

        this.app.appendChild(dashboard);

        // Bind Events
        document.getElementById('logout-btn').addEventListener('click', () => AuthManager.logout());

        // Modal Logic
        const modal = document.getElementById('student-modal');
        const closeModal = () => {
            modal.classList.add('hidden');
            document.getElementById('student-form').reset();
            document.getElementById('edit-mode-id').value = '';
            document.getElementById('modal-title').textContent = 'Add New Student';
            document.getElementById('inp-id').disabled = false;
        };

        document.getElementById('add-student-btn').addEventListener('click', () => {
            modal.classList.remove('hidden');
        });
        document.getElementById('close-modal').addEventListener('click', closeModal);

        // Save Student
        document.getElementById('student-form').addEventListener('submit', (e) => {
            e.preventDefault();
            // Collect Data
            const id = document.getElementById('inp-id').value;
            const existingId = document.getElementById('edit-mode-id').value;

            // Basic data construction
            const studentData = {
                id: id,
                fullName: document.getElementById('inp-name').value,
                password: document.getElementById('inp-password').value, // Simple handling
                grade: document.getElementById('inp-grade').value,
                parentPhone: document.getElementById('inp-phone').value,
                fees: {
                    status: document.getElementById('inp-fee-status').value,
                    amount: 0,
                    due: 0
                },
                subjects: []
            };

            // Parse Marks
            try {
                const marksRaw = document.getElementById('inp-marks').value;
                if (marksRaw) studentData.subjects = JSON.parse(marksRaw);
            } catch (err) {
                alert('Invalid JSON for marks');
                return;
            }

            try {
                if (existingId) {
                    DataManager.updateStudent(existingId, studentData);
                } else {
                    DataManager.addStudent(studentData);
                }
                closeModal();
                this.refreshStudentTable();
            } catch (err) {
                alert(err.message);
            }
        });

        // Initial Load
        this.refreshStudentTable();

        // Search
        document.getElementById('search-student').addEventListener('input', (e) => {
            this.refreshStudentTable(e.target.value);
        });
    },

    refreshStudentTable(query = '') {
        const tbody = document.getElementById('student-table-body');
        const students = DataManager.getStudents();
        const filtered = students.filter(s =>
            s.fullName.toLowerCase().includes(query.toLowerCase()) ||
            s.id.toLowerCase().includes(query.toLowerCase())
        );

        document.getElementById('total-students-count').textContent = students.length;

        tbody.innerHTML = filtered.map(s => `
            <tr class="border-b hover:bg-slate-50">
                <td class="p-4 font-bold text-slate-700">${s.id}</td>
                <td class="p-4">
                    <div class="font-medium">${s.fullName}</div>
                    <div class="text-xs text-gray-500">${s.parentPhone || 'No Phone'}</div>
                </td>
                <td class="p-4"><span class="bg-blue-100 text-blue-800 text-xs font-semibold px-2 py-1 rounded">${s.grade}</span></td>
                <td class="p-4">
                    <span class="px-2 py-1 rounded text-xs font-bold ${s.fees.status === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}">
                        ${s.fees.status}
                    </span>
                </td>
                <td class="p-4 text-center">
                    <button class="text-blue-500 hover:text-blue-700 mx-1 btn-edit" data-id="${s.id}"><i class="fas fa-edit"></i></button>
                    <button class="text-red-500 hover:text-red-700 mx-1 btn-delete" data-id="${s.id}"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
        `).join('');

        // Attach event listeners to new buttons
        document.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click', () => this.openEditModal(btn.dataset.id));
        });
        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', () => {
                if (confirm('Are you sure you want to delete this student?')) {
                    DataManager.deleteStudent(btn.dataset.id);
                    this.refreshStudentTable();
                }
            });
        });
    },

    openEditModal(id) {
        const student = DataManager.getStudentById(id);
        if (!student) return;

        document.getElementById('modal-title').textContent = 'Edit Student';
        document.getElementById('edit-mode-id').value = student.id;

        document.getElementById('inp-id').value = student.id;
        document.getElementById('inp-id').disabled = true; // Cannot change ID
        document.getElementById('inp-name').value = student.fullName;
        document.getElementById('inp-password').value = student.password || '';
        document.getElementById('inp-grade').value = student.grade;
        document.getElementById('inp-phone').value = student.parentPhone || '';
        document.getElementById('inp-fee-status').value = student.fees.status;
        document.getElementById('inp-marks').value = JSON.stringify(student.subjects || [], null, 2);

        document.getElementById('student-modal').classList.remove('hidden');
    },


    // --- Student Dashboard ---
    renderStudentDashboard(user) {
        this.clearApp();
        const dashboard = document.createElement('div');
        dashboard.className = 'flex flex-col min-h-screen bg-slate-50';

        // Calculate Totals
        const subjects = user.subjects || [];
        const totalMarks = subjects.reduce((sum, sub) => sum + sub.marks, 0);
        const average = subjects.length ? (totalMarks / subjects.length).toFixed(1) : 0;

        dashboard.innerHTML = `
             <nav class="bg-primary text-white p-4 shadow-lg" style="background-color: var(--primary-color);">
                <div class="container mx-auto flex justify-between items-center">
                    <div class="flex items-center gap-3">
                        <i class="fas fa-user-graduate text-3xl text-accent"></i>
                        <div>
                            <h1 class="font-bold text-lg leading-tight">Student Portal</h1>
                            <p class="text-xs text-gray-400">Welcome, ${user.fullName}</p>
                        </div>
                    </div>
                    <button id="logout-btn" class="btn bg-white/10 text-white border-0 hover:bg-white/20">Logout</button>
                </div>
            </nav>

            <main class="container mx-auto p-4 md:p-8 space-y-6">
                
                <!-- Info Cards -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Profile Card -->
                    <div class="card p-6 flex items-center gap-4 border-t-4 border-blue-600">
                        <div class="bg-blue-100 p-3 rounded-full text-blue-600">
                            <i class="fas fa-id-card text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Student ID</p>
                            <h3 class="font-bold text-xl">${user.id}</h3>
                            <p class="text-xs text-gray-400">Class: ${user.grade}</p>
                        </div>
                    </div>

                     <!-- Fee Status -->
                    <div class="card p-6 flex items-center gap-4 border-t-4 ${user.fees.status === 'Paid' ? 'border-green-500' : 'border-red-500'}">
                        <div class="${user.fees.status === 'Paid' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'} p-3 rounded-full">
                            <i class="fas fa-money-bill-wave text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Fee Status</p>
                            <h3 class="font-bold text-xl ${user.fees.status === 'Paid' ? 'text-green-600' : 'text-red-600'}">${user.fees.status}</h3>
                        </div>
                    </div>

                    <!-- Performance -->
                    <div class="card p-6 flex items-center gap-4 border-t-4 border-amber-500">
                        <div class="bg-amber-100 p-3 rounded-full text-amber-600">
                            <i class="fas fa-chart-line text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Overall Average</p>
                            <h3 class="font-bold text-xl">${average}%</h3>
                        </div>
                    </div>
                </div>

                <!-- Marks Table -->
                <div class="card overflow-hidden">
                    <div class="bg-slate-50 p-4 border-b flex justify-between items-center">
                        <h2 class="font-bold text-lg text-slate-700">Academic Results</h2>
                        <span class="text-sm bg-slate-200 px-2 py-1 rounded">Term 1</span>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-slate-50 text-slate-500 text-xs uppercase font-semibold">
                                <tr>
                                    <th class="p-4">Subject</th>
                                    <th class="p-4 text-center">Marks</th>
                                    <th class="p-4 text-center">Grade</th>
                                    <th class="p-4 text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                ${subjects.map(sub => `
                                    <tr class="hover:bg-slate-50">
                                        <td class="p-4 font-medium text-slate-700">${sub.name}</td>
                                        <td class="p-4 text-center font-bold">${sub.marks}</td>
                                        <td class="p-4 text-center">
                                            <span class="inline-block w-8 h-8 leading-8 rounded-full bg-slate-100 font-bold text-slate-600 text-xs">${sub.grade}</span>
                                        </td>
                                        <td class="p-4 text-center">
                                            <span class="text-xs font-bold ${sub.marks >= 50 ? 'text-green-500' : 'text-red-500'}">
                                                ${sub.marks >= 50 ? 'PASS' : 'FAIL'}
                                            </span>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                             <tfoot class="bg-slate-50 font-bold text-slate-700">
                                <tr>
                                    <td class="p-4">Total</td>
                                    <td class="p-4 text-center">${totalMarks}</td>
                                    <td class="p-4" colspan="2"></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>

                <div class="text-center text-sm text-gray-400 mt-8 pb-8">
                    &copy; ${new Date().getFullYear()} Imaamu Saqaawi Primary & Secondary School
                </div>
            </main>
        `;

        this.app.appendChild(dashboard);

        document.getElementById('logout-btn').addEventListener('click', () => AuthManager.logout());
    }
};
